import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from models.common import knn, rigid_transform_3d
from utils.SE3 import transform


class SpatialAttention(nn.Module):
    def __init__(self):
        super(SpatialAttention, self).__init__()
        self.conv1 = nn.Conv1d(2, 1, kernel_size=1)  # concat完channel维度为2
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        def global_std_pool2d(x):
            """2D global standard variation pooling"""
            return torch.std(x, dim=1, keepdim=True)

        avg_out = torch.mean(x, dim=1, keepdim=True)  # 沿着channel 维度计算均值和最大值
        std_pool = global_std_pool2d(x)
        x = torch.cat([avg_out, std_pool], dim=1)
        x = self.conv1(x)
        return self.sigmoid(x)


class ChannelAttention(nn.Module):
    def __init__(self, in_planes, ratio=16):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool1d(1)
        self.max_pool = nn.AdaptiveMaxPool1d(1)

        self.fc1 = nn.Conv1d(in_planes, in_planes // 16, 1, bias=False)
        self.relu1 = nn.ReLU()
        self.fc2 = nn.Conv1d(in_planes // 16, in_planes, 1, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        def global_std_pool2d(x):
            """2D global standard variation pooling"""
            return torch.std(x, dim=2, keepdim=True)

        std_pool = global_std_pool2d(x)
        avg_out = self.fc2(self.relu1(self.fc1(self.avg_pool(x))))
        std_out = self.fc2(self.relu1(self.fc1(std_pool)))
        out = avg_out + std_out
        return self.sigmoid(out)


class GDFA(nn.Module):
    def __init__(self, channels, out_channels=None):
        nn.Module.__init__(self)
        sub_channels = channels // 4
        self.conv1 = nn.Sequential(
            nn.InstanceNorm1d(sub_channels, eps=1e-3),
            nn.BatchNorm1d(sub_channels),
            nn.ReLU(),
            nn.Conv1d(sub_channels, sub_channels, kernel_size=1),
        )
        self.conv2 = nn.Sequential(
            nn.InstanceNorm1d(sub_channels, eps=1e-3),
            nn.BatchNorm1d(sub_channels),
            nn.ReLU(),
            nn.Conv1d(sub_channels, sub_channels, kernel_size=1),
        )
        self.conv3 = nn.Sequential(
            nn.InstanceNorm1d(sub_channels, eps=1e-3),
            nn.BatchNorm1d(sub_channels),
            nn.ReLU(),
            nn.Conv1d(sub_channels, sub_channels, kernel_size=1),
        )
        self.conv4 = nn.Sequential(
            nn.InstanceNorm1d(sub_channels, eps=1e-3),
            nn.BatchNorm1d(sub_channels),
            nn.ReLU(),
            nn.Conv1d(sub_channels, sub_channels, kernel_size=1),
        )
        self.CA = ChannelAttention(channels)

    def channel_shuffle(self, x, groups):
        batchsize, num_channels, num_corr = x.data.size()

        channels_per_group = num_channels // groups

        # reshape
        x = x.view(batchsize, groups,
                   channels_per_group, num_corr)

        # transpose
        # - contiguous() required if transpose() is used before view().
        #   See https://github.com/pytorch/pytorch/issues/764
        x = torch.transpose(x, 1, 2).contiguous()

        # flatten
        x = x.view(batchsize, -1, num_corr)

        return x

    def forward(self, x):
        spx = torch.split(x, 32, 1)
        sp1 = self.conv1(spx[0])

        sp2 = sp1 + spx[1] + spx[0]
        sp2 = self.conv2(sp2)

        sp3 = sp2 + spx[2] + spx[1] + spx[0]
        sp3 = self.conv3(sp3)

        sp4 = sp3 + spx[3] + spx[2] + spx[1] + spx[0]
        sp4 = self.conv4(sp4)

        out = torch.cat((sp1, sp2, sp3, sp4), 1)
        out = out + x
        out = self.channel_shuffle(out, 4)
        return out


class SCNonLocalA(nn.Module):
    def __init__(self, num_channels=128, num_heads=1, psp_size=(1, 3, 6, 8)):
        super(SCNonLocalA, self).__init__()

        self.fc_message1 = nn.Sequential(
            nn.Conv1d(num_channels, num_channels // 2, kernel_size=1),
            nn.InstanceNorm1d(num_channels // 2, eps=1e-3),
            nn.BatchNorm1d(num_channels // 2),
            nn.ReLU(inplace=True),
            nn.Conv1d(num_channels // 2, num_channels // 2, kernel_size=1),
            nn.InstanceNorm1d(num_channels // 2, eps=1e-3),
            nn.BatchNorm1d(num_channels // 2),
            nn.ReLU(inplace=True),
            nn.Conv1d(num_channels // 2, num_channels, kernel_size=1),
        )
        self.projection_q = nn.Sequential(
            nn.InstanceNorm1d(num_channels, eps=1e-3),
            nn.BatchNorm1d(num_channels),
            nn.ReLU(),
            nn.Conv1d(num_channels, num_channels, kernel_size=1),
        )
        self.projection_k = nn.Sequential(
            nn.InstanceNorm1d(num_channels, eps=1e-3),
            nn.BatchNorm1d(num_channels),
            nn.ReLU(),
            nn.Conv1d(num_channels, num_channels, kernel_size=1),
        )
        self.projection_v = nn.Sequential(
            nn.InstanceNorm1d(num_channels, eps=1e-3),
            nn.BatchNorm1d(num_channels),
            nn.ReLU(),
            nn.Conv1d(num_channels, num_channels, kernel_size=1),
        )

        self.num_channels = num_channels
        self.head = num_heads

        self.CA = ChannelAttention(num_channels)
        self.SA = SpatialAttention()

    def forward(self, feat, attention):
        """
        Input:
            - feat:     [bs, num_channels, num_corr]  input feature
            - attention [bs, num_corr, num_corr]      spatial consistency matrix
        Output:
            - res:      [bs, num_channels, num_corr]  updated feature
        """
        bs, num_corr = feat.shape[0], feat.shape[-1]
        Q = self.projection_q(feat).view([bs, self.head, self.num_channels // self.head, num_corr])
        K = self.projection_k(feat).view([bs, self.head, self.num_channels // self.head, num_corr])
        V = self.projection_v(feat).view([bs, self.head, self.num_channels // self.head, num_corr])
        feat_attention = torch.einsum('bhco, bhci->bhoi', Q, K) / (self.num_channels // self.head) ** 0.5
        weight = torch.softmax(attention[:, None, :, :] * feat_attention, dim=-1)
        message = torch.einsum('bhoi, bhci-> bhco', weight, V).reshape([bs, -1, num_corr])
        message = self.fc_message1(message)
        w_ca = self.CA(message)
        out_c = w_ca * message

        w_sa = self.SA(out_c)
        out_s = w_sa * out_c
        out = feat + out_s
        return out


class CEBlock(nn.Module):
    def __init__(self, in_dim=6, num_layers=6, num_channels=128):
        super(CEBlock, self).__init__()
        self.num_layers = num_layers
        self.blocks = nn.ModuleDict()
        self.layer0 = nn.Conv1d(in_dim, num_channels, kernel_size=1, bias=True)
        self.CA = ChannelAttention(num_channels)
        self.SA = SpatialAttention()
        for i in range(num_layers):
            layer = GDFA(num_channels)
            self.blocks[f'PointCN_layer_{i}'] = layer
            self.blocks[f'NonLocal_layer_{i}'] = SCNonLocalA(num_channels)

    def forward(self, corr_feat, corr_compatibility):
        """
        Input:
            - corr_feat:          [bs, in_dim, num_corr]   input feature map
            - corr_compatibility: [bs, num_corr, num_corr] spatial consistency matrix
        Output:
            - feat:               [bs, num_channels, num_corr] updated feature
        """
        feat = self.layer0(corr_feat)
        for i in range(self.num_layers):
            message = self.blocks[f'PointCN_layer_{i}'](feat)
            ca = self.CA(message)
            out_ca = ca * message
            sa = self.SA(out_ca)
            out_sa = sa * out_ca
            feat = feat + out_sa
            feat = self.blocks[f'NonLocal_layer_{i}'](feat, corr_compatibility)
        return feat


class Multi(nn.Module):
    def __init__(self, num_channels=128, num_heads=1):
        nn.Module.__init__(self)
        self.message1 = nn.Sequential(
            nn.InstanceNorm1d(128, eps=1e-3),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Conv1d(128, 128, kernel_size=1),
        )

        self.message2 = nn.Sequential(
            nn.InstanceNorm1d(128, eps=1e-3),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Conv1d(128, 64, kernel_size=1),
        )

        self.message3 = nn.Sequential(
            nn.InstanceNorm1d(64, eps=1e-3),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Conv1d(64, 32, kernel_size=1),
        )

        self.message4 = nn.Sequential(
            nn.InstanceNorm1d(32, eps=1e-3),
            nn.BatchNorm1d(32),
            nn.ReLU(),
            nn.Conv1d(32, 16, kernel_size=1),
        )

        self.message5 = nn.Sequential(
            nn.InstanceNorm1d(16, eps=1e-3),
            nn.BatchNorm1d(16),
            nn.ReLU(),
            nn.Conv1d(16, 16, kernel_size=1),
        )

        self.message6 = nn.Sequential(
            nn.InstanceNorm1d(16, eps=1e-3),
            nn.BatchNorm1d(16),
            nn.ReLU(),
            nn.Conv1d(16, 32, kernel_size=1),
        )

        self.message7 = nn.Sequential(
            nn.InstanceNorm1d(32, eps=1e-3),
            nn.BatchNorm1d(32),
            nn.ReLU(),
            nn.Conv1d(32, 64, kernel_size=1),
        )

        self.message8 = nn.Sequential(
            nn.InstanceNorm1d(64, eps=1e-3),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Conv1d(64, 128, kernel_size=1),
        )

        self.conv = nn.Sequential(
            nn.InstanceNorm1d(240, eps=1e-3),
            nn.BatchNorm1d(240),
            nn.ReLU(),
            nn.Conv1d(240, 128, kernel_size=1),
        )

        self.down_pool = torch.nn.AvgPool1d(2)

        self.conv1 = nn.Sequential(nn.Conv2d(128 * 2, 128, kernel_size=1, bias=False),
                                   nn.BatchNorm2d(128),
                                   nn.LeakyReLU(negative_slope=0.2))

        self.fc_message1 = nn.Sequential(
            nn.Conv1d(num_channels, num_channels // 2, kernel_size=1),
            nn.InstanceNorm1d(num_channels // 2, eps=1e-3),
            nn.BatchNorm1d(num_channels // 2),
            nn.ReLU(inplace=True),
            nn.Conv1d(num_channels // 2, num_channels // 2, kernel_size=1),
            nn.InstanceNorm1d(num_channels // 2, eps=1e-3),
            nn.BatchNorm1d(num_channels // 2),
            nn.ReLU(inplace=True),
            nn.Conv1d(num_channels // 2, num_channels, kernel_size=1),
        )
        self.fc_message2 = nn.Sequential(
            nn.Conv1d(num_channels, num_channels // 2, kernel_size=1),
            nn.InstanceNorm1d(num_channels // 2, eps=1e-3),
            nn.BatchNorm1d(num_channels // 2),
            nn.ReLU(inplace=True),
            nn.Conv1d(num_channels // 2, num_channels // 2, kernel_size=1),
            nn.InstanceNorm1d(num_channels // 2, eps=1e-3),
            nn.BatchNorm1d(num_channels // 2),
            nn.ReLU(inplace=True),
            nn.Conv1d(num_channels // 2, num_channels, kernel_size=1),
        )
        self.projection_q = nn.Sequential(
            nn.InstanceNorm1d(num_channels, eps=1e-3),
            nn.BatchNorm1d(num_channels),
            nn.ReLU(),
            nn.Conv1d(num_channels, num_channels, kernel_size=1),
        )
        self.projection_k = nn.Sequential(
            nn.InstanceNorm1d(num_channels, eps=1e-3),
            nn.BatchNorm1d(num_channels),
            nn.ReLU(),
            nn.Conv1d(num_channels, num_channels, kernel_size=1),
        )
        self.projection_v = nn.Sequential(
            nn.InstanceNorm1d(num_channels, eps=1e-3),
            nn.BatchNorm1d(num_channels),
            nn.ReLU(),
            nn.Conv1d(num_channels, num_channels, kernel_size=1),
        )

        self.num_channels = num_channels
        self.head = num_heads

        self.temperature1 = nn.Parameter(torch.ones(num_heads, 1, 1))
        self.temperature2 = nn.Parameter(torch.ones(num_heads, 1, 1))

    def get_graph_feature(self, x, k=9, idx=None):
        # x[32,128,2000,1],k=9
        # x[32,128,1000,1],k=6
        batch_size = x.size(0)
        num_points = x.size(2)
        x = x.view(batch_size, -1, num_points)  # x[32,128,2000]
        if idx is None:
            idx_out = self.knn(x, k=k)  # idx_out[32,2000,9]
        else:
            idx_out = idx
        device = x.device

        idx_base = torch.arange(0, batch_size, device=device).view(-1, 1, 1) * num_points

        idx = idx_out + idx_base  # idx[32,2000,9] 把32个批次的标号连续了

        idx = idx.view(-1)  # idx[32*2000*9] 把32个批次连在一起了 [32*1000*6]

        _, num_dims, _ = x.size()

        x = x.transpose(2, 1).contiguous()  # x[32,2000,128]
        feature = x.view(batch_size * num_points, -1)[idx, :]
        feature = feature.view(batch_size, num_points, k, num_dims)  # feature[32,2000,9,128]
        x = x.view(batch_size, num_points, 1, num_dims).repeat(1, 1, k, 1)  # x[32,2000,9,128]
        feature = torch.cat((x, x - feature), dim=3).permute(0, 3, 1, 2).contiguous()  # feature[32,256,2000,9] 图特征
        return feature

    def knn(self, x, k):
        inner = -2 * torch.matmul(x.transpose(2, 1), x)
        xx = torch.sum(x ** 2, dim=1, keepdim=True)
        pairwise_distance = -xx - inner - xx.transpose(2, 1)

        idx = pairwise_distance.topk(k=k, dim=-1)[1]  # (batch_size, num_points, k)
        return idx

    def channel_shuffle(self, x, groups):
        batchsize, num_channels, num_corr = x.data.size()

        channels_per_group = num_channels // groups

        # reshape
        x = x.view(batchsize, groups,
                   channels_per_group, num_corr)

        # transpose
        # - contiguous() required if transpose() is used before view().
        #   See https://github.com/pytorch/pytorch/issues/764
        x = torch.transpose(x, 1, 2).contiguous()

        # flatten
        x = x.view(batchsize, -1, num_corr)

        return x

    def forward(self, x, attention):

        bs, num_corr = x.shape[0], x.shape[-1]
        Q = self.projection_q(x).view([bs, self.head, self.num_channels // self.head, num_corr])
        K = self.projection_k(x).view([bs, self.head, self.num_channels // self.head, num_corr])
        V = self.projection_v(x).view([bs, self.head, self.num_channels // self.head, num_corr])

        feat_attention = (Q.transpose(-2, -1) @ K) * self.temperature1
        feat_attention = feat_attention.softmax(dim=-1)
        message = (V @ feat_attention).reshape([bs, -1, num_corr])
        message1 = self.fc_message1(message)
        message1 = message1 + x

        attn = (Q @ K.transpose(-2, -1)) * self.temperature2  # 形成d×d，而不是N×N
        attn = attn.softmax(dim=-1)
        message = (attn @ V).reshape([bs, -1, num_corr])
        message2 = self.fc_message2(message)
        message2 = message2 + x

        f1 = message1.permute(0, 2, 1)
        f2 = self.down_pool(f1)
        f3 = self.down_pool(f2)
        f4 = self.down_pool(f3)

        f5 = message2.permute(0, 2, 1)
        f6 = self.down_pool(f5)
        f7 = self.down_pool(f6)
        f8 = self.down_pool(f7)

        f1 = f1.permute(0, 2, 1)
        f2 = f2.permute(0, 2, 1)
        f3 = f3.permute(0, 2, 1)
        f4 = f4.permute(0, 2, 1)

        f5 = f5.permute(0, 2, 1)
        f6 = f6.permute(0, 2, 1)
        f7 = f7.permute(0, 2, 1)
        f8 = f8.permute(0, 2, 1)

        s1 = self.message1(f1) + f1
        s2 = self.message2(s1) + f2
        s3 = self.message3(s2) + f3
        s4 = self.message4(s3) + f4

        s5 = self.message5(f4) + f8
        s6 = self.message6(s5) + f7
        s7 = self.message7(s6) + f6
        s8 = self.message8(s7) + f5

        s_down1 = s1 + s8
        s_down2 = s2 + s7
        s_down3 = s3 + s6
        s_down4 = s4 + s5

        out = torch.cat((s_down1, s_down2, s_down3, s_down4), dim=1)
        out = self.conv(out)
        out = out + x
        out = self.channel_shuffle(out, 4)

        return out


class GlobalContext(nn.Module):
    def __init__(self, channels, reduction=4):
        super(GlobalContext, self).__init__()
        inter_channels = int(channels // reduction)
        self.conv = nn.Sequential(
            nn.Conv1d(channels, inter_channels, kernel_size=1),
            nn.SyncBatchNorm(inter_channels),
            nn.ReLU(inplace=True),
            nn.Conv1d(inter_channels, channels, kernel_size=1),
        )
        self.conv1 = nn.Sequential(
            nn.Conv1d(2 * channels, channels, kernel_size=1),
            nn.SyncBatchNorm(channels),
            nn.ReLU(inplace=True),
            nn.Conv1d(channels, channels, kernel_size=1),
        )

    def forward(self, x, logits):
        w = logits.unsqueeze(1)  # b*1*n
        w = torch.tanh(torch.relu(w))
        w = F.normalize(w, p=1, dim=2)

        x_w = torch.mul(x, w.expand_as(x))  # b*c*n
        x_sum = torch.sum(x_w, dim=2, keepdim=True)  # bc1

        global_context = F.normalize(self.conv(x_sum), p=2, dim=1)  # bc1

        proj_length = torch.bmm(x.transpose(1, 2), global_context).transpose(1, 2)  # b1n
        proj = torch.mul(proj_length, global_context)  # bcn
        orth_comp = x - proj  # bcn
        final_feat = x + self.conv1(
            torch.cat([orth_comp, global_context.expand_as(orth_comp)], dim=1))  # b 2c n => b c n

        return final_feat


class GPINet(nn.Module):
    def __init__(self,
                 in_dim=6,
                 num_layers=6,
                 num_channels=128,
                 num_iterations=10,
                 ratio=0.1,
                 inlier_threshold=0.10,
                 sigma_d=0.10,
                 sigma_a=3.20,
                 k=30,
                 nms_radius=0.10,
                 use_mutal=True,
                 d_thre=0.1,
                 max_points=8000,
                 k1=30,
                 k2=20,
                 select_scene=None,
                 ):
        super(GPINet, self).__init__()
        self.num_iterations = num_iterations  # maximum iteration of power iteration algorithm
        self.ratio = ratio  # the maximum ratio of seeds.
        self.num_channels = num_channels
        self.inlier_threshold = inlier_threshold
        self.sigma = nn.Parameter(torch.Tensor([1.0]).float(), requires_grad=True)
        self.sigma_spat = nn.Parameter(torch.Tensor([sigma_d]).float(), requires_grad=False)
        self.k = k  # neighborhood number in NSM module.
        self.nms_radius = nms_radius  # only used during testing
        self.max_points = max_points
        self.k1 = k1
        self.k2 = k2
        self.d_thre = d_thre
        self.factor_a = 180.0 / (15 * np.pi)
        self.out = nn.Conv1d(num_channels, 1, kernel_size=1)
        self.layer1 = nn.Conv1d(7, 6, kernel_size=1, bias=True)
        self.encoder = CEBlock(
            in_dim=in_dim,
            num_layers=num_layers,
            num_channels=num_channels,
        )

        self.classification = nn.Sequential(
            nn.Conv1d(num_channels, 32, kernel_size=1, bias=True),
            nn.ReLU(inplace=True),
            nn.Conv1d(32, 32, kernel_size=1, bias=True),
            nn.ReLU(inplace=True),
            nn.Conv1d(32, 1, kernel_size=1, bias=True),
        )

        self.multi = Multi()
        # self.global_fusion = GlobalContext(128)

        # initialization
        for m in self.modules():
            if isinstance(m, (nn.Conv1d, nn.Linear)):
                nn.init.xavier_normal_(m.weight, gain=1)
            elif isinstance(m, (nn.BatchNorm1d)):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def forward(self, data):
        """
        Input:
            - corr_pos:   [bs, num_corr, 6]
            - src_keypts: [bs, num_corr, 3]
            - tgt_keypts: [bs, num_corr, 3]
            - testing:    flag for test phase, if False will not calculate M and post-refinement.
        Output: (dict)
            - final_trans:   [bs, 4, 4], the predicted transformation matrix.
            - final_labels:  [bs, num_corr], the predicted inlier/outlier label (0,1), for classification loss calculation.
            - M:             [bs, num_corr, num_corr], feature similarity matrix, for SM loss calculation.
            - seed_trans:    [bs, num_seeds, 4, 4],  the predicted transformation matrix associated with each seeding point, deprecated.
            - corr_features: [bs, num_corr, num_channels], the feature for each correspondence, for circle loss calculation, deprecated.
            - confidence:    [bs], confidence of returned results, for safe guard, deprecated.
        """
        corr_pos, src_keypts, tgt_keypts = data['corr_pos'], data['src_keypts'], data['tgt_keypts']
        bs, num_corr = corr_pos.shape[0], corr_pos.shape[1]
        testing = 'testing' in data.keys()

        #################################
        # Step1: extract feature for each correspondence
        #################################
        with torch.no_grad():
            src_dist = torch.norm((src_keypts[:, :, None, :] - src_keypts[:, None, :, :]), dim=-1)  # [1, 5182, 5182]
            corr_compatibility = src_dist - torch.norm((tgt_keypts[:, :, None, :] - tgt_keypts[:, None, :, :]),
                                                       dim=-1)
            corr_compatibility = torch.clamp(1.0 - corr_compatibility ** 2 / self.sigma_spat ** 2, min=0)

        corr_features = self.encoder(corr_pos.permute(0, 2, 1), corr_compatibility).permute(0, 2, 1)
        normed_corr_features = F.normalize(corr_features, p=2, dim=-1)

        if not testing:  # during training or validation
            # construct the feature similarity matrix M for loss calculation
            M = torch.matmul(normed_corr_features, normed_corr_features.permute(0, 2, 1))
            M = torch.clamp(1 - (1 - M) / self.sigma ** 2, min=0, max=1)
            # set diagnal of M to zero
            M[:, torch.arange(M.shape[1]), torch.arange(M.shape[1])] = 0
        else:
            M = None

            #################################
        # Step 2.1: estimate initial confidence by MLP, find highly confident and well-distributed points as seeds.
        #################################
        # confidence = self.cal_leading_eigenvector(M.to(corr_pos.device), method='power')
        confidence = self.classification(corr_features.permute(0, 2, 1)).squeeze(1)

        if testing:
            seeds = self.pick_seeds(src_dist, confidence, R=self.nms_radius, max_num=int(num_corr * self.ratio))
        else:
            seeds = torch.argsort(confidence, dim=1, descending=True)[:, 0:int(num_corr * self.ratio)]

        #################################
        # Step 3 & 4: calculate transformation matrix for each seed, and find the best hypothesis.
        #################################
        seed_trans, seed_fitness, final_trans, final_labels, final_labels1 = self.cal_seed_trans(seeds,
                                                                                                 normed_corr_features,
                                                                                                 src_keypts, tgt_keypts)

        final_labels1 = final_labels1.unsqueeze(1)  # [1,1,12000]
        out = torch.cat([corr_pos.permute(0, 2, 1), final_labels1.detach()], dim=1)
        out = self.layer1(out)
        corr_features = self.encoder(out, corr_compatibility).permute(0, 2, 1)

        # confidence = self.classification(corr_features.permute(0, 2, 1)).squeeze(1)
        # corr_features = self.global_fusion(corr_features.permute(0, 2, 1), confidence).permute(0, 2, 1)
        corr_features = self.multi(corr_features.permute(0, 2, 1), corr_compatibility).permute(0, 2, 1)

        normed_corr_features = F.normalize(corr_features, p=2, dim=-1)

        if not testing:  # during training or validation
            # construct the feature similarity matrix M for loss calculation
            M = torch.matmul(normed_corr_features, normed_corr_features.permute(0, 2, 1))
            M = torch.clamp(1 - (1 - M) / self.sigma ** 2, min=0, max=1)
            # set diagnal of M to zero
            M[:, torch.arange(M.shape[1]), torch.arange(M.shape[1])] = 0
        else:
            M = None

        confidence = self.classification(corr_features.permute(0, 2, 1)).squeeze(1)

        if testing:
            seeds = self.pick_seeds(src_dist, confidence, R=self.nms_radius, max_num=int(num_corr * self.ratio))
        else:
            seeds = torch.argsort(confidence, dim=1, descending=True)[:, 0:int(num_corr * self.ratio)]

        seed_trans, seed_fitness, final_trans, final_labels, final_labels1 = self.cal_seed_trans(seeds,
                                                                                                 normed_corr_features,
                                                                                                 src_keypts, tgt_keypts)

        # post refinement (only used during testing and bs == 1)
        if testing:
            final_trans = self.post_refinement(final_trans, src_keypts, tgt_keypts)

        ## during training, return the initial confidence as logits for classification loss
        ## during testing, return the final labels given by final transformation.
        if not testing:
            final_labels = confidence
        res = {
            "final_trans": final_trans,
            "final_labels": final_labels,
            "M": M
        }
        return res

    def pick_seeds(self, dists, scores, R, max_num):
        """
        Select seeding points using Non Maximum Suppression. (here we only support bs=1)
        Input:
            - dists:       [bs, num_corr, num_corr] src keypoints distance matrix
            - scores:      [bs, num_corr]     initial confidence of each correspondence
            - R:           float              radius of nms
            - max_num:     int                maximum number of returned seeds
        Output:
            - picked_seeds: [bs, num_seeds]   the index to the seeding correspondences
        """
        assert scores.shape[0] == 1

        # parallel Non Maximum Suppression (more efficient)
        score_relation = scores.T >= scores  # [num_corr, num_corr], save the relation of leading_eig
        # score_relation[dists[0] >= R] = 1  # mask out the non-neighborhood node
        score_relation = score_relation.bool() | (dists[0] >= R).bool()
        is_local_max = score_relation.min(-1)[0].float()
        return torch.argsort(scores * is_local_max, dim=1, descending=True)[:, 0:max_num].detach()

    def cal_seed_trans(self, seeds, corr_features, src_keypts, tgt_keypts):
        """
        Calculate the transformation for each seeding correspondences.
        Input:
            - seeds:         [bs, num_seeds]              the index to the seeding correspondence
            - corr_features: [bs, num_corr, num_channels] [1,5182,128]
            - src_keypts:    [bs, num_corr, 3]
            - tgt_keypts:    [bs, num_corr, 3]
        Output: leading eigenvector
            - pairwise_trans:    [bs, num_seeds, 4, 4]  transformation matrix for each seeding point.
            - pairwise_fitness:  [bs, num_seeds]        fitness (inlier ratio) for each seeding point
            - final_trans:       [bs, 4, 4]             best transformation matrix (after post refinement) for each batch.
            - final_labels:      [bs, num_corr]         inlier/outlier label given by best transformation matrix.
        """
        bs, num_corr, num_channels = corr_features.shape[0], corr_features.shape[1], corr_features.shape[2]
        num_seeds = seeds.shape[-1]
        k = min(self.k, num_corr - 1)
        knn_idx = knn(corr_features, k=k, ignore_self=True, normalized=True)  # [bs, num_corr, k] [1,5182,40]
        knn_idx = knn_idx.gather(dim=1, index=seeds[:, :, None].expand(-1, -1, k))  # [bs, num_seeds, k] [1,518,40]

        #################################
        # construct the feature consistency matrix of each correspondence subset.
        #################################
        knn_features = corr_features.gather(dim=1,
                                            index=knn_idx.view([bs, -1])[:, :, None].expand(-1, -1, num_channels)).view(
            [bs, -1, k, num_channels])  # [bs, num_seeds, k, num_channels]
        knn_M = torch.matmul(knn_features, knn_features.permute(0, 1, 3, 2))
        knn_M = torch.clamp(1 - (1 - knn_M) / self.sigma ** 2, min=0)  # [1,518,40,40]
        # knn_M = knn_M.view([-1, k, k])
        feature_knn_M = knn_M

        #################################
        # construct the spatial consistency matrix of each correspondence subset.
        #################################
        src_knn = src_keypts.gather(dim=1, index=knn_idx.view([bs, -1])[:, :, None].expand(-1, -1, 3)).view(
            [bs, -1, k, 3])  # [bs, num_seeds, k, 3] [1,518,40,3]
        tgt_knn = tgt_keypts.gather(dim=1, index=knn_idx.view([bs, -1])[:, :, None].expand(-1, -1, 3)).view(
            [bs, -1, k, 3])
        knn_M = ((src_knn[:, :, :, None, :] - src_knn[:, :, None, :, :]) ** 2).sum(-1) ** 0.5 - (
                (tgt_knn[:, :, :, None, :] - tgt_knn[:, :, None, :, :]) ** 2).sum(-1) ** 0.5
        # knn_M = torch.max(torch.zeros_like(knn_M), 1.0 - knn_M ** 2 / self.sigma_spat ** 2)
        knn_M = torch.clamp(1 - knn_M ** 2 / self.sigma_spat ** 2, min=0)  # [1,518,40,40]
        # knn_M = knn_M.view([-1, k, k]) #[518,40,40]
        spatial_knn_M = knn_M

        #################################
        # Power iteratation to get the inlier probability
        #################################
        total_knn_M = feature_knn_M * spatial_knn_M
        total_knn_M = torch.matmul(total_knn_M[:, :, :1, :], total_knn_M)

        k1 = self.k1
        k2 = self.k2

        if k1 > num_channels:
            k1 = 4
            k2 = 4
        sorted_score = torch.argsort(total_knn_M, dim=3, descending=True)
        knn_idx_fine = sorted_score[:, :, :, 0: k2]  # [1,518,40,40]
        num = knn_idx_fine.shape[1]
        # src_knn_fine = src_knn.gather(dim=1, index=knn_idx_fine.view([bs, num, -1])[:, :, :, None].expand(-1, -1, -1, 3)).view([bs, -1, k2, 3])
        # tgt_knn_fine = tgt_knn.gather(dim=1, index=knn_idx_fine.view([bs, num, -1])[:, :, :, None].expand(-1, -1, -1, 3)).view([bs, -1, k2, 3])
        knn_idx_fine = knn_idx_fine.contiguous().view([bs, num, -1])[:, :, :, None]  # [1,518,40,40]
        knn_idx_fine = knn_idx_fine.expand(-1, -1, -1, 3)  # [1,518,1200,3]
        src_knn_fine = src_knn.gather(dim=2, index=knn_idx_fine).view(
            [bs, -1, k2, 3])  # [1,20720,40,3] [bs, num_seeds, k, 3]
        tgt_knn_fine = tgt_knn.gather(dim=2, index=knn_idx_fine).view([bs, -1, k2, 3])
        knn_M = ((src_knn_fine[:, :, :, None, :] - src_knn_fine[:, :, None, :, :]) ** 2).sum(-1) ** 0.5 - (
                (tgt_knn_fine[:, :, :, None, :] - tgt_knn_fine[:, :, None, :, :]) ** 2).sum(-1) ** 0.5
        # knn_M = torch.max(torch.zeros_like(knn_M), 1.0 - knn_M ** 2 / self.sigma_spat ** 2)
        knn_M = torch.clamp(1 - knn_M ** 2 / self.sigma_spat ** 2, min=0)  # [1,518,40,40]
        knn_M = knn_M.view([-1, k2, k2])  # [518,40,40]
        spatial_knn_M = knn_M

        total_knn_M = spatial_knn_M

        total_knn_M[:, torch.arange(total_knn_M.shape[1]), torch.arange(total_knn_M.shape[1])] = 0
        # total_knn_M = self.gamma * feature_knn_M + (1 - self.gamma) * spatial_knn_M
        total_weight = self.cal_leading_eigenvector(total_knn_M, method='power')
        total_weight = total_weight.view([bs, -1, k2])
        total_weight = total_weight / (torch.sum(total_weight, dim=-1, keepdim=True) + 1e-6)

        #################################
        # calculate the transformation by weighted least-squares for each subsets in parallel
        #################################
        total_weight = total_weight.view([-1, k2])

        src_knn = src_knn_fine
        tgt_knn = tgt_knn_fine
        src_knn, tgt_knn = src_knn.view([-1, k2, 3]), tgt_knn.view([-1, k2, 3])
        seed_as_center = False

        if seed_as_center:
            # if use seeds as the neighborhood centers
            src_center = src_keypts.gather(dim=1, index=seeds[:, :, None].expand(-1, -1, 3))  # [bs, num_seeds, 3]
            tgt_center = tgt_keypts.gather(dim=1, index=seeds[:, :, None].expand(-1, -1, 3))  # [bs, num_seeds, 3]
            src_center, tgt_center = src_center.view([-1, 3]), tgt_center.view([-1, 3])
            src_pts = src_knn[:, :, :, None] - src_center[:, None, :, None]  # [bs*num_seeds, k, 3, 1]
            tgt_pts = tgt_knn[:, :, :, None] - tgt_center[:, None, :, None]  # [bs*num_seeds, k, 3, 1]
            cov = torch.einsum('nkmo,nkop->nkmp', src_pts, tgt_pts.permute(0, 1, 3, 2))  # [bs*num_seeds, k, 3, 3]
            Covariances = torch.einsum('nkmp,nk->nmp', cov, total_weight)  # [bs*num_seeds, 3, 3]

            # use svd to recover the transformation for each seeding point, torch.svd is much faster on cpu.
            U, S, Vt = torch.svd(Covariances.cpu())
            U, S, Vt = U.cuda(), S.cuda(), Vt.cuda()
            delta_UV = torch.det(Vt @ U.permute(0, 2, 1))
            eye = torch.eye(3)[None, :, :].repeat(U.shape[0], 1, 1).to(U.device)
            eye[:, -1, -1] = delta_UV
            R = Vt @ eye @ U.permute(0, 2, 1)  # [num_pair, 3, 3]
            t = tgt_center[:, None, :] - src_center[:, None, :] @ R.permute(0, 2, 1)  # [num_pair, 1, 3]

            seedwise_trans = torch.eye(4)[None, :, :].repeat(R.shape[0], 1, 1).to(R.device)
            seedwise_trans[:, 0:3, 0:3] = R.permute(0, 2, 1)
            seedwise_trans[:, 0:3, 3:4] = t.permute(0, 2, 1)
            seedwise_trans = seedwise_trans.view([bs, -1, 4, 4])
        else:
            # not use seeds as neighborhood centers.
            seedwise_trans = rigid_transform_3d(src_knn, tgt_knn, total_weight)
            seedwise_trans = seedwise_trans.view([bs, -1, 4, 4])

        #################################
        # calculate the inlier number for each hypothesis, and find the best transformation for each point cloud pair
        #################################
        pred_position = torch.einsum('bsnm,bmk->bsnk', seedwise_trans[:, :, :3, :3],
                                     src_keypts.permute(0, 2, 1)) + seedwise_trans[:, :, :3,
                                                                    3:4]  # [bs, num_seeds, num_corr, 3]
        pred_position = pred_position.permute(0, 1, 3, 2)
        L2_dis = torch.norm(pred_position - tgt_keypts[:, None, :, :], dim=-1)  # [bs, num_seeds, num_corr]
        seedwise_fitness = torch.mean((L2_dis < self.inlier_threshold).float(), dim=-1)  # [bs, num_seeds]
        # seedwise_inlier_rmse = torch.sum(L2_dis * (L2_dis < config.inlier_threshold).float(), dim=1)
        batch_best_guess = seedwise_fitness.argmax(dim=1)

        # refine the pose by using all the inlier correspondences (done in the post-refinement step)
        final_trans = seedwise_trans.gather(dim=1,
                                            index=batch_best_guess[:, None, None, None].expand(-1, -1, 4, 4)).squeeze(1)
        final_labels = L2_dis.gather(dim=1,
                                     index=batch_best_guess[:, None, None].expand(-1, -1, L2_dis.shape[2])).squeeze(1)
        final_labels1 = final_labels
        final_labels = (final_labels1 < self.inlier_threshold).float()
        return seedwise_trans, seedwise_fitness, final_trans, final_labels, final_labels1

    def cal_leading_eigenvector(self, M, method='power'):
        """
        Calculate the leading eigenvector using power iteration algorithm or torch.symeig
        Input:
            - M:      [bs, num_corr, num_corr] the compatibility matrix
            - method: select different method for calculating the learding eigenvector.
        Output:
            - solution: [bs, num_corr] leading eigenvector
        """
        if method == 'power':
            # power iteration algorithm
            leading_eig = torch.ones_like(M[:, :, 0:1])
            leading_eig_last = leading_eig
            for i in range(self.num_iterations):
                leading_eig = torch.bmm(M, leading_eig)
                leading_eig = leading_eig / (torch.norm(leading_eig, dim=1, keepdim=True) + 1e-6)
                if torch.allclose(leading_eig, leading_eig_last):
                    break
                leading_eig_last = leading_eig
            leading_eig = leading_eig.squeeze(-1)
            return leading_eig
        elif method == 'eig':  # cause NaN during back-prop
            e, v = torch.symeig(M, eigenvectors=True)
            leading_eig = v[:, :, -1]
            return leading_eig
        else:
            exit(-1)

    def cal_confidence(self, M, leading_eig, method='eig_value'):
        """
        Calculate the confidence of the spectral matching solution based on spectral analysis.
        Input:
            - M:          [bs, num_corr, num_corr] the compatibility matrix
            - leading_eig [bs, num_corr]           the leading eigenvector of matrix M
        Output:
            - confidence
        """
        if method == 'eig_value':
            # max eigenvalue as the confidence (Rayleigh quotient)
            max_eig_value = (leading_eig[:, None, :] @ M @ leading_eig[:, :, None]) / (
                    leading_eig[:, None, :] @ leading_eig[:, :, None])
            confidence = max_eig_value.squeeze(-1)
            return confidence
        elif method == 'eig_value_ratio':
            # max eigenvalue / second max eigenvalue as the confidence
            max_eig_value = (leading_eig[:, None, :] @ M @ leading_eig[:, :, None]) / (
                    leading_eig[:, None, :] @ leading_eig[:, :, None])
            # compute the second largest eigen-value
            B = M - max_eig_value * leading_eig[:, :, None] @ leading_eig[:, None, :]
            solution = torch.ones_like(B[:, :, 0:1])
            for i in range(self.num_iterations):
                solution = torch.bmm(B, solution)
                solution = solution / (torch.norm(solution, dim=1, keepdim=True) + 1e-6)
            solution = solution.squeeze(-1)
            second_eig = solution
            second_eig_value = (second_eig[:, None, :] @ B @ second_eig[:, :, None]) / (
                    second_eig[:, None, :] @ second_eig[:, :, None])
            confidence = max_eig_value / second_eig_value
            return confidence
        elif method == 'xMx':
            # max xMx as the confidence (x is the binary solution)
            # rank = torch.argsort(leading_eig, dim=1, descending=True)[:, 0:int(M.shape[1]*self.ratio)]
            # binary_sol = torch.zeros_like(leading_eig)
            # binary_sol[0, rank[0]] = 1
            confidence = leading_eig[:, None, :] @ M @ leading_eig[:, :, None]
            confidence = confidence.squeeze(-1) / M.shape[1]
            return confidence

    def post_refinement(self, initial_trans, src_keypts, tgt_keypts, weights=None):
        """
        Perform post refinement using the initial transformation matrix, only adopted during testing.
        Input
            - initial_trans: [bs, 4, 4]
            - src_keypts:    [bs, num_corr, 3]
            - tgt_keypts:    [bs, num_corr, 3]
            - weights:       [bs, num_corr]
        Output:
            - final_trans:   [bs, 4, 4]
        """
        assert initial_trans.shape[0] == 1
        if self.inlier_threshold == 0.10:  # for 3DMatch
            inlier_threshold_list = [0.10] * 20
        else:  # for KITTI
            inlier_threshold_list = [1.2] * 20

        previous_inlier_num = 0
        for inlier_threshold in inlier_threshold_list:
            warped_src_keypts = transform(src_keypts, initial_trans)
            L2_dis = torch.norm(warped_src_keypts - tgt_keypts, dim=-1)
            pred_inlier = (L2_dis < inlier_threshold)[0]  # assume bs = 1
            inlier_num = torch.sum(pred_inlier)
            if abs(int(inlier_num - previous_inlier_num)) < 1:
                break
            else:
                previous_inlier_num = inlier_num
            initial_trans = rigid_transform_3d(
                A=src_keypts[:, pred_inlier, :],
                B=tgt_keypts[:, pred_inlier, :],
                ## https://link.springer.com/article/10.1007/s10589-014-9643-2
                # weights=None,
                weights=1 / (1 + (L2_dis / inlier_threshold) ** 2)[:, pred_inlier],
                # weights=((1-L2_dis/inlier_threshold)**2)[:, pred_inlier]
            )
        return initial_trans
